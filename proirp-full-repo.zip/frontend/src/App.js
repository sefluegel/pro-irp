
import React from 'react';

function App() {
  return (
    <div>
      <h1>Pro IRP MVP Dashboard</h1>
      <p>Welcome to the churn-prediction dashboard.</p>
    </div>
  );
}

export default App;
